<?php

   //$baseUrl = "http://sewing.denimsdts.com/";
   $baseUrl = "http://localhost/sdlsoftware/";
   $baseName = "sdlsoftware";
   $baseIcon = "logo.png";
?>
