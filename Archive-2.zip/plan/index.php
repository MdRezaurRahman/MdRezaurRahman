<?php
require_once(dirname(__FILE__)."/pages/login.php");
?>
