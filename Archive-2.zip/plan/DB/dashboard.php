<?php
require_once dirname(__FILE__).('/db_con.php');

class dashboard extends DB_CON
{

    public function getTotalOrderQuantity(){
      $con = $this->connectToDB();

      date_default_timezone_set("Asia/Dhaka");
      $year = date("Y");
      $month = date("m");
      $monthYear = $month."-".$year;

      $sql = "SELECT ifnull(sum(quantity),0) as totalQuantity
              FROM `order_qtn_size` left join `order_details` on `order_details`.id = `order_qtn_size`.order_id
              WHERE order_details.creation_date  LIKE '%".$monthYear."'
              and `order_details`.deletion_status != 1";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          $result = mysqli_fetch_assoc($query_result);
          return $result['totalQuantity'];
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }


    public function getTotalCuttingProductionQuantity(){
      $con = $this->connectToDB();

      date_default_timezone_set("Asia/Dhaka");
      $year = date("Y");
      $month = date("m");
      $monthYear = $month."-".$year;

      $sql = "SELECT ifnull(sum(quantity),0) as totalQuantity
              FROM `cut_pro_bundle`
              WHERE cut_pro_bundle.creation_date  LIKE '%".$monthYear."'
              and deletion_status != '1'";
      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          $result = mysqli_fetch_assoc($query_result);
          return $result['totalQuantity'];
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }


    public function getTotalInputIssue(){

      $con = $this->connectToDB();

      date_default_timezone_set("Asia/Dhaka");
      $year = date("Y");
      $month = date("m");
      $monthYear = $month."-".$year;

      $sql = "SELECT
              `cut_pro_bundle`.`quantity`  as quantity,
              cutting_production.lay as lay,
              IFNULL((select sum(quantity) from cut_pro_bundle
              where ticket_no = cut_pro_bundle.ticket_no),0) as total_quantity_bundle,
              (select user_name from user where id = bp_issue.scan_user)  as user_name
              FROM ((`bp_issue` left join `cut_pro_bundle`
              on `cut_pro_bundle`.id = `bp_issue`.b_tkt_code)
              left join `cutting_production`
              on `cut_pro_bundle`.production_id = `cutting_production`.id)
              where bp_issue.date like '%".$monthYear."'
              and bp_issue.deletion_status != 1
              order by `bp_issue`.id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {

          $totalQuantity = 0;
          while($row = mysqli_fetch_assoc($query_result))
          {
            $totalQuantity += $row['quantity'];
          }

          return $totalQuantity;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }


	public function getTotalnewInputIssue(){

      $con = $this->connectToDB();

      date_default_timezone_set("Asia/Dhaka");
      $year = date("Y");
      $month = date("m");
      $monthYear = $month."-".$year;

      $sql = "SELECT
              `cut_pro_bundle`.`quantity`  as quantity,
              cutting_production.lay as lay,
              IFNULL((select sum(quantity) from cut_pro_bundle
              where ticket_no = cut_pro_bundle.ticket_no),0) as total_quantity_bundle,
              (select user_name from user where id = bp_issue.scan_user)  as user_name
              FROM ((`bp_issue` left join `cut_pro_bundle`
              on `cut_pro_bundle`.id = `bp_issue`.b_tkt_code)
              left join `cutting_production`
              on `cut_pro_bundle`.production_id = `cutting_production`.id)
              where bp_issue.date like '%".$monthYear."'
              and bp_issue.deletion_status != 1
              order by `bp_issue`.id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {

          $totalQuantity = 0;
          while($row = mysqli_fetch_assoc($query_result))
          {
            $totalQuantity += $row['quantity'];
          }

          return $totalQuantity;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }


	public function totalsewingoutputqty(){

      $con = $this->connectToDB();

      date_default_timezone_set("Asia/Dhaka");
      $year = date("Y");
      $month = date("m");
      //$monthYear = $month."-".$year;
      $yearMonth = $year."-".$month;

      $sql = "SELECT
            COUNT(*) AS t_qty
            FROM swing_output_scan
            WHERE deletion_status != 1
            and date like '".$yearMonth."%' ";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }

	public function sewingoutputqtyunit($unit){

      $con = $this->connectToDB();

      date_default_timezone_set("Asia/Dhaka");
      $year = date("Y");
      $month = date("m");
      //$monthYear = $month."-".$year;
      $yearMonth = $year."-".$month;
      $where = "";
      if($unit==1){
        $where .= " and (line = 'Line 1' or line = 'Line 2' or line = 'Line 3' or line = 'Line 4' or line = 'Line 5' or line = 'Line 6' or line = 'Line 7' or line = 'Line 8') ";
        // $where .= " or line = 'Line 2' ";
        // $where .= " or line = 'Line 3' ";
        // $where .= " or line = 'Line 4' ";
        // $where .= " or line = 'Line 5' ";
        // $where .= " or line = 'Line 6' ";
        // $where .= " or line = 'Line 7' ";
        // $where .= " or line = 'Line 8' ";
      }
      if($unit==2){
        $where .= " and (line = 'Line 9' or line = 'Line 10' or line = 'Line 11' or line = 'Line 12' or line = 'Line 13' or line = 'Line 14' or line = 'Line 15' or line = 'Line 16') ";
        // $where .= " or line = 'Line 10' ";
        // $where .= " or line = 'Line 11' ";
        // $where .= " or line = 'Line 12' ";
        // $where .= " or line = 'Line 13' ";
        // $where .= " or line = 'Line 14' ";
        // $where .= " or line = 'Line 15' ";
        // $where .= " or line = 'Line 16' ";
      }
      if($unit==3){
        $where .= " and (line = 'Line 18' or line = 'Line 19' or line = 'Line 20') ";
        // $where .= " or line = 'Line 18' ";
        // $where .= " or line = 'Line 19' ";
        // $where .= " or line = 'Line 20' ";
      }

      $sql = "SELECT
            COUNT(*) AS t_qty
            FROM swing_output_scan
            WHERE deletion_status != 1
            $where
            and date like '".$yearMonth."%' ";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }

	public function todaysewingoutputqtyunit($unit){

      $con = $this->connectToDB();

      date_default_timezone_set("Asia/Dhaka");
      $year = date("Y");
      $month = date("m");
      $day = date("d");
      //$monthYear = $month."-".$year;
      $yearMonthDay = $year."-".$month."-".$day;
      //return $yearMonthDay;
      $where = "";
      if($unit==1){
        $where .= " and (line = 'Line 1' or line = 'Line 2' or line = 'Line 3' or line = 'Line 4' or line = 'Line 5' or line = 'Line 6' or line = 'Line 7' or line = 'Line 8') ";
        // $where .= " or line = 'Line 2' ";
        // $where .= " or line = 'Line 3' ";
        // $where .= " or line = 'Line 4' ";
        // $where .= " or line = 'Line 5' ";
        // $where .= " or line = 'Line 6' ";
        // $where .= " or line = 'Line 7' ";
        // $where .= " or line = 'Line 8' ";
      }
      if($unit==2){
        $where .= " and (line = 'Line 9' or line = 'Line 10' or line = 'Line 11' or line = 'Line 12' or line = 'Line 13' or line = 'Line 14' or line = 'Line 15' or line = 'Line 16') ";
        // $where .= " or line = 'Line 10' ";
        // $where .= " or line = 'Line 11' ";
        // $where .= " or line = 'Line 12' ";
        // $where .= " or line = 'Line 13' ";
        // $where .= " or line = 'Line 14' ";
        // $where .= " or line = 'Line 15' ";
        // $where .= " or line = 'Line 16' ";
      }
      if($unit==3){
        $where .= " and (line = 'Line 18' or line = 'Line 19' or line = 'Line 20') ";
        // $where .= " or line = 'Line 18' ";
        // $where .= " or line = 'Line 19' ";
        // $where .= " or line = 'Line 20' ";
      }

      $sql = "SELECT
            COUNT(*) AS t_qty
            FROM swing_output_scan
            WHERE deletion_status != 1
            $where
            and date = '$yearMonthDay' ";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }



	public function totalwashsendqty(){

      $con = $this->connectToDB();

      date_default_timezone_set("Asia/Dhaka");
      $year = date("Y");
      $month = date("m");
      $monthYear = $month."-".$year;

      $sql = "SELECT
              `cut_pro_bundle`.`quantity`  as quantity,
              cutting_production.lay as lay,
              IFNULL((select sum(quantity) from cut_pro_bundle
              where ticket_no = cut_pro_bundle.ticket_no),0) as total_quantity_bundle,
              (select user_name from user where id = bp_issue.scan_user)  as user_name
              FROM ((`bp_issue` left join `cut_pro_bundle`
              on `cut_pro_bundle`.id = `bp_issue`.b_tkt_code)
              left join `cutting_production`
              on `cut_pro_bundle`.production_id = `cutting_production`.id)
              where bp_issue.date like '%".$monthYear."'
              and bp_issue.deletion_status != 1
              order by `bp_issue`.id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {

          $totalQuantity = 0;
          while($row = mysqli_fetch_assoc($query_result))
          {
            $totalQuantity += $row['quantity'];
          }

          return $totalQuantity;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }



	public function totalwashreceivedqty(){

      $con = $this->connectToDB();

      date_default_timezone_set("Asia/Dhaka");
      $year = date("Y");
      $month = date("m");
      $monthYear = $month."-".$year;

      $sql = "SELECT
              `cut_pro_bundle`.`quantity`  as quantity,
              cutting_production.lay as lay,
              IFNULL((select sum(quantity) from cut_pro_bundle
              where ticket_no = cut_pro_bundle.ticket_no),0) as total_quantity_bundle,
              (select user_name from user where id = bp_issue.scan_user)  as user_name
              FROM ((`bp_issue` left join `cut_pro_bundle`
              on `cut_pro_bundle`.id = `bp_issue`.b_tkt_code)
              left join `cutting_production`
              on `cut_pro_bundle`.production_id = `cutting_production`.id)
              where bp_issue.date like '%".$monthYear."'
              and bp_issue.deletion_status != 1
              order by `bp_issue`.id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {

          $totalQuantity = 0;
          while($row = mysqli_fetch_assoc($query_result))
          {
            $totalQuantity += $row['quantity'];
          }

          return $totalQuantity;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }


	public function totalfinishinginputqty(){

      $con = $this->connectToDB();

      date_default_timezone_set("Asia/Dhaka");
      $year = date("Y");
      $month = date("m");
      $monthYear = $month."-".$year;

      $sql = "SELECT
              `cut_pro_bundle`.`quantity`  as quantity,
              cutting_production.lay as lay,
              IFNULL((select sum(quantity) from cut_pro_bundle
              where ticket_no = cut_pro_bundle.ticket_no),0) as total_quantity_bundle,
              (select user_name from user where id = bp_issue.scan_user)  as user_name
              FROM ((`bp_issue` left join `cut_pro_bundle`
              on `cut_pro_bundle`.id = `bp_issue`.b_tkt_code)
              left join `cutting_production`
              on `cut_pro_bundle`.production_id = `cutting_production`.id)
              where bp_issue.date like '%".$monthYear."'
              and bp_issue.deletion_status != 1
              order by `bp_issue`.id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {

          $totalQuantity = 0;
          while($row = mysqli_fetch_assoc($query_result))
          {
            $totalQuantity += $row['quantity'];
          }

          return $totalQuantity;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }


	public function totalfinishingoutputqty(){

      $con = $this->connectToDB();

      date_default_timezone_set("Asia/Dhaka");
      $year = date("Y");
      $month = date("m");
      $monthYear = $month."-".$year;

      $sql = "SELECT
              `cut_pro_bundle`.`quantity`  as quantity,
              cutting_production.lay as lay,
              IFNULL((select sum(quantity) from cut_pro_bundle
              where ticket_no = cut_pro_bundle.ticket_no),0) as total_quantity_bundle,
              (select user_name from user where id = bp_issue.scan_user)  as user_name
              FROM ((`bp_issue` left join `cut_pro_bundle`
              on `cut_pro_bundle`.id = `bp_issue`.b_tkt_code)
              left join `cutting_production`
              on `cut_pro_bundle`.production_id = `cutting_production`.id)
              where bp_issue.date like '%".$monthYear."'
              and bp_issue.deletion_status != 1
              order by `bp_issue`.id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {

          $totalQuantity = 0;
          while($row = mysqli_fetch_assoc($query_result))
          {
            $totalQuantity += $row['quantity'];
          }

          return $totalQuantity;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }



    public function getTotalTrimsInhouse()
    {
        $con = $this->connectToDB();

        date_default_timezone_set("Asia/Dhaka");
        $year = date("Y");
        $month = date("m");
        $monthYear = $month."-".$year;

        $sql = "SELECT
                trim_inhouse.*,
                (select sum(required_quantity) from trinhouse_name where trinhouse_id = trim_inhouse.id)  as total_requirement,
                (select sum(receive_quantity) from trinhouse_name where trinhouse_id = trim_inhouse.id)  as total_received,
                (select sum(total_issue_quantity) from trinhouse_name where trinhouse_id = trim_inhouse.id)  as total_issue,
                (select sum(balance_quantity) from trinhouse_name where trinhouse_id = trim_inhouse.id)  as total_balance
                FROM `trim_inhouse`
                where trim_inhouse.creation_date like '%".$monthYear."'
                and deletion_status != 1

                order by trim_inhouse.id desc";

        $query_result = mysqli_query($con, $sql);
        if ($query_result) {
            return $query_result;
        } else {
            die('Query problem' . mysqli_error($con));
        }
    }

    public function getswoutputQtyByLine()
    {
      $con = $this->connectToDB();

      $sql = "SELECT line,
              SUM(quantity) as t_qty
              FROM swing_output_scan
              WHERE deletion_status != 1
              GROUP BY line
              order by line";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }


}

?>
