<?php
    echo date('d-m-y');
    echo "<br>";
    echo date('D-m-y');

    echo "<br>";
    echo date('d/M/y');

    echo "<br>";
    echo date('d-M-y');

    echo "<br>";
    echo date('d-M-Y');

    date_default_timezone_set('asia/dhaka');

    echo "<br>";
    echo date('d-F-y');

    echo "<br>";
    echo date('d-F-y h:i:s');

    echo "<br>";
    echo date('d-F-y h:i:s a');

    echo "<br>";
    echo date('d-F-y h:i:s A');

    echo "<br>";
    echo date('d-F-y H:i:s A');

    echo "<br>";
    echo date('d-F-y H:i:s A');

    echo "<br>";
    echo date('d-M-y H:i:s A (w)');

    echo "<br>";
    echo date('d-M-y H:i:s A (W)');

    echo "<br>";
    echo date('d-M-y H:i:s A (l)');

    echo "<br>";
    echo date_default_timezone_get();

    echo "<br>";

    //mk time
    $mytime = mktime (0,0,0, 9,10,2025);
    
    echo date('d-M-y h:i:s A (l)');
    echo "<br>";

    //shorttime

    $tomorrow = strtotime('next day');
    echo date('d-M-y h:i:s A (l)',$tomorrow );
    echo "<br>";

   $testtime = strtotime("+2 years +3 months -5 days");

   echo date('d-M-y h:i:s A (l)',$testtime );
   echo "<br>";


   $testtime = strtotime("+2 years +3 months -5 days");

   echo date('d-M-y h:i:s A (l)',$testtime );
   echo "<br>";

   echo "<br>";
   echo "<br>";

   $startDate = strtotime("Friday");
   $endDate = strtotime(" +10 weeks", $startDate );

   while ($startDate < $endDate){
    echo date('d-M-y h:i:s A (l)',$startDate );
    echo "<br>";
    $startDate = strtotime("+1 weeks", $startDate);

   }
   echo "<br>";
   
    $daterrr = strtotime (" first day of next year");
    echo date('d-M-y h:i:s A (l)',$daterrr );
    echo "<br>";



?>