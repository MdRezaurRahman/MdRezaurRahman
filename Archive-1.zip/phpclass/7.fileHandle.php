<?php


echo readfile("./test.txt")."<br>";

$openfile = fopen("./test.txt", "r");
echo fread($openfile,filesize("./test.txt"))."<br>";
fclose($openfile);

echo "<br>";
// echo filesize("./test.txt") ."<br>";

$openfile = fopen("./test.txt", "r");
echo fgets($openfile);
echo fgets($openfile);

fclose($openfile);


echo "<br>";

$lopfile = fopen("./test.txt", "r");
while(!feof($lopfile)){
    echo fgets($lopfile)."<br>";
}
fclose($openfile);

echo "<br>";

$filewr = fopen("./fe.txt", "a");
fwrite($filewr, "Kamal is not Bad Boy\n");
fclose($filewr);

$lpfile = fopen("./fe.txt", "r");
while(!feof($lpfile)){
    echo fgets($lpfile)."<br>";
}
fclose($lpfile);

echo "<br>";

$fileopen = fopen("./test.pdf", "w");
fwrite($fileopen, "halum" );
fclose($fileopen);

echo "<br>";

$opn = fopen("./tes.pdf", "w");
fwrite($opn, "hi i am good man");
fclose($opn);

mkdir("./dhaka");
 


?>