<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "plan_insert";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  echo " not connected";
}

?>