
<?php

if(isset($_POST['addstudent'])){
    $s_name = $_POST['sname'];
    $s_email = $_POST['semail'];


if(empty($s_name)){
    $sname_err = "<span style='color:red'> pls write Your Name </span>";
}else{
    $style_corr=$s_name;
}

if(empty($s_email)){
    $semail_err = "<span style= 'color:red' > Pls wrie your email </span>";
}else{
    $po_corr=$s_email;
}
if(isset($style_corr) && isset($po_corr)){
    $savedata = "data saved successfully";
}

}

?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <title>form</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

    </head>
    <body>


    <form action="" method="post" style="text-align:center;">

    <h1 style="color: red;"  > Pls fill-up red mark writing </h1>

    Style Name: <input type="text" placeholder="Your Name" name="sname" value="<?=$s_name??null;?>">
    <?= $sname_err ?? null; ?>
    <br><br>

    Po Number: <input type="text" placeholder="Your Email" name="semail" value="<?=$s_email??null;?>">
    <?= $semail_err ?? null; ?>
    <br> <br>


    <input type="submit" name="addstudent" value="Add Student">
    <br> <br>
    <?= $savedata ?? null; ?>
    </form>
    </body>
</html>



<?php



$mysqli = new mysqli("localhost","root","","plan_insert");

if ($mysqli -> connect_error) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}

$mysqli -> query("INSERT INTO data_insert (style_name,po_number	) VALUES ('$s_name', '$s_email')");


// Print auto-generated id

$mysqli -> close();

?>
