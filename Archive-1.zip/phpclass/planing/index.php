<!DOCTYPE html>
<?php 
	include 'db.php';

?>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title> Import Excel File </title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Import Excel File To MySql Database Using php">

		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/bootstrap-responsive.min.css">
		<link rel="stylesheet" href="css/bootstrap-custom.css">

	</head>
	<body>

	<!-- Navbar
    ================================================== -->

	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container">
				<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a class="brand" href="#">Import CSV File </a>

			</div>
		</div>
	</div>

	<div id="wrap">
	<div class="container">
		<div class="row">
			<div class="span3 hidden-phone"></div>
			<div class="span6" id="form-login">
				<form class="form-horizontal well" action="import.php" method="post" name="upload_excel" enctype="multipart/form-data">
					<fieldset>
						<legend>Import CSV/Excel file</legend>
						<div class="control-group">
							<div class="control-label">
								<label>CSV/Excel File:</label>
							</div>
							<div class="controls">
								<input type="file" name="file" id="file" class="input-large">
							</div>
						</div>

						<div class="control-group">
							<div class="controls">
							<button type="submit" id="submit" name="Import" class="btn btn-primary button-loading" data-loading-text="Loading...">Upload</button>
							</div>
						</div>
					</fieldset>
				</form>
			</div>
			<div class="span3 hidden-phone"></div>
		</div>

		<table class="table table-bordered" border="2px" style="color: black;">
			<thead>
				  	<tr>
				  		<th> S.No </th>
				  		<th> Style Name </th>
				  		<th> PO Number </th>
				  		<th> Department </th>
				  		<th> OPD Year Week </th>
						<th> PSD Year Week </th>
						<th> PED Year Week </th>
						<th> TOD PED Month </th>
						<th> TOD PED Week </th>
						<th> TOD Year Month </th>
						<th> Booked Placed Qty </th>
						<th> Allocated Booked & Placed Qty </th>
						<th>
							<a href=""> Action </a>
						</th>
				  	</tr>

				  </thead>
			<?php
				$SQLSELECT = "SELECT * FROM subject ";
				$result_set =  mysqli_query($conn, $SQLSELECT);
				while($row = mysqli_fetch_array($result_set))
				{
				?>

					<tr>
						<td><?php echo $row['id']; ?></td>
						<td><?php echo $row['style']; ?></td>
						<td><?php echo $row['po_number']; ?></td>
						<td><?php echo $row['department']; ?></td>
						<td><?php echo $row['opd_year_week']; ?></td>
						<td><?php echo $row['psd_year_week']; ?></td>
						<td><?php echo $row['ped_year_week']; ?></td>
						<td><?php echo $row['tod_per_month']; ?></td>
						<td><?php echo $row['tod_per_week']; ?></td>
						<td><?php echo $row['tod_year_month']; ?></td>
						<td><?php echo $row['booked_placed_qty']; ?></td>
						<td><?php echo $row['allocated_booked_placed_qty']; ?></td>
						<td>
							<a href="edit.php"> Edit </a>
							<a href="edit.php"> Delete </a>
						</td>

					</tr>
				<?php
				}
			?>
		</table>
	</div>

	</div>

	</body>
</html>