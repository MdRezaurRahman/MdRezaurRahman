<?php
    require_once('./insert.php');
?>