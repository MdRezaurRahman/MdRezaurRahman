<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "plan_insert";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  echo " not connected";
}



if(!isset($_GET['id'])){
    header(("location: update.php"));
}else{
    $id = $_GET['id'];
}


$selectupdate = $conn->query("SELECT * FROM `data_insert`");
$updatedata= $selectupdate ->fetch_array();


if(isset($_POST['updatestyle'])){
    $style_name = $_POST['style_name'];
    $po_number=$_POST['po_number'];
    $color=$_POST['color'];

    if(empty($style_name)){
        $error_style="<span style='color:red'> Plz fill style name </span>";
    }

    if(empty($po_number)){
        $error_po="<span style='color:red' > Plz fill po number </span>";
    }

    if(empty($color)){
        $error_color="<span style='color:red' > Plz fill color </span>";
    }

}


?>

<form action="" method="post" >

    <table border="2px" style="border-color: crimson;">

    <tr>
        <td>  Style Name: </td>
        <td> PO Number: </td>
        <td> Color: </td>
    </tr>
    <tr>

    <td>
    <input type="text" placeholder="style Name" name="style_name" value="<?=$updatedata['style'];?>">
    <?=$error_style??null?>
    </td>

    <td>
        <input type="text" placeholder="PO Number" name="po_number" value="">
        <?= $error_po??null ?>
        </td>

        <td>
        <input type="text" placeholder="Color" name="color" value="">
        <?= $error_color??null ?>
        </td>

    </tr>


    <tr>
        <td>    <input type="submit" name="updatestyle" value="update Style"> </td>
    </tr>

    </table>

    </form>