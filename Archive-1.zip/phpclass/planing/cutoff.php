<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>

<table border="2px">
<tr>
    <td> Year </td>
    <td> Week </td>
    <td> Shipment Date </td>
</tr>

<tr>

<td>

<select name="select">
<?php
   for($year = 2020 ; $year < date('Y'); $year++){
      echo "<option>$year</option>";
   }



$dayofweek = date('w', strtotime($date));
$result    = date('Y-m-d', strtotime(($day - $dayofweek).' day', strtotime($date)));


?>


</select>

    </td>

    <td>

    <?php
    for ($x = 1; $x <= 52; $x++) {
    echo '<option value="'.$x.'" >week '.$x.'</option>';
    }
    ?>
    <input type="checkbox" name="weeknumber" value="">

    </td>
    <td>
    
    </td>

</tr>




</table>




    </body>
</html>
