<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "plan_insert";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  echo " not connected";
}



$selectdata = "SELECT * FROM `data_insert`";
$select_query = $conn->query($selectdata);


?>


<table border="2px">

<tr>

<td> S.No</td>
<td> Style Name </td>
<td> PO Number </td>
<td> department </td>
<td> opd_year_week </td>
<td> psd_year_week </td>
<td> ped_year_week </td>
<td> tod_per_month </td>
<td> tod_per_week </td>
<td> Action </td>

</tr>

<?php
$slno = 1;
while($databaseinfo = $select_query->fetch_array()){

?>
<tr>

    <td> <?= $slno; ?> </td>
    <td> <?= $databaseinfo["style"]; ?> </td>
    <td> <?= $databaseinfo["po_number"]; ?> </td>
    <td> <?= $databaseinfo["department"]; ?> </td>
    <td> <?= $databaseinfo["opd_year_week"]; ?> </td>
    <td> <?= $databaseinfo["psd_year_week"]; ?> </td>
    <td> <?= $databaseinfo["ped_year_week"]; ?> </td>
    <td> <?= $databaseinfo["tod_per_month"]; ?> </td>
    <td> <?= $databaseinfo["tod_per_week"]; ?> </td>
    <td>
        <a href="edit.php?id=<?= $databaseinfo["id"];?>">Update</a>
        <a href="delete.php">Delete</a>
    </td>

</tr>

<?php $slno++; } ?>

</table>
