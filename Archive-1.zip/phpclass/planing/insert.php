
<?php

if(isset($_POST['addstyle'])){
    $style_name = $_POST['style_name'];
    $po_number=$_POST['po_number'];
    $color=$_POST['color'];

    if(empty($style_name)){
        $error_style="<span style='color:red'> Plz fill style name </span>";
    }

    if(empty($po_number)){
        $error_po="<span style='color:red' > Plz fill po number </span>";
    }

    if(empty($color)){
        $error_color="<span style='color:red' > Plz fill color </span>";
    }


}

?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>


    <form action="" method="post" >

    <table border="2px" style="border-color: crimson;">

    <tr>
        <td>  Style Name: </td>
        <td> PO Number: </td>
        <td> Color: </td>
    </tr>
    <tr>

    <td>
    <input type="text" placeholder="style Name" name="style_name" value="<?=$style_name??null;?>">
    <?=$error_style??null?>
    </td>

    <td>
        <input type="text" placeholder="PO Number" name="po_number" value="<?=$po_number??null;?>">
        <?= $error_po??null ?>
        </td>

        <td>
        <input type="text" placeholder="Color" name="color" value="<?=$color??null;?>">
        <?= $error_color??null ?>
        </td>

    </tr>


    <tr>
        <td>    <input type="submit" name="addstyle" value="Add Style"> </td>
    </tr>

    </table>

    </form>

    </body>
</html>

<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "plan_insert";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$insert_data = "INSERT INTO data_insert (style_name, po_number, color)
VALUES ('$style_name', '$po_number', '$color')";

if(mysqli_query($conn,$insert_data)){
    echo "<span style= 'color: green'> Data inserted Successfully </span>";
}else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
  $conn->close();


?>
