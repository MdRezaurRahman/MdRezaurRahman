
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "plan_insert";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// $selectdata = "SELECT *  FROM `data_insert`";
// $Dataresult = $conn->query($selectdata);


$sql = "SELECT * FROM `data_insert` ";
$result = $conn->query($sql);

// if ($result->num_rows > 0) {
//   // output data of each row
//   while($row = $result->fetch_assoc()) {
//     echo "id: " .$row["S.No"]. " - Name: " .$row["firstname"]. " " .$row["lastname"]. "<br>";
//   }
// } else {
//   echo "0 results";
// }
// $conn->close();

?>

<table border="2px" >
  <tr style="text-align: center;">

    <td> S.No </td>
    <td> Style Name </td>
    <td> PO Number </td>
    <td> Color </td>
    <td>Action</td>

  </tr>

  <?php

    while ($row = $result->fetch_array()) {

  ?>

<tr>

  <td style="text-align: center;"> <?= $row["id"]??null; ?> </td>
  <td> <?= $row["style_name"]??null; ?> </td>
  <td> <?= $row["po_number"]??null; ?> </td>
  <td> <?= $row["color"]??null; ?> </td>
  <td>
    <a href="./update.php">Edit</a>
    <a href="delete.php"> Delete</a>
  </td>

  </tr>


<?php

}
?>
</table>
