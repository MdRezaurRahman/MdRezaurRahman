<?php

    $x= 0;

    while ($x < 10){
        echo $x ."<br>";
        $x++;
    }


echo "<br>";

    $y = 0;

do{
    echo$y . "<br>";
    $y++;
}while($y <= 10);


echo "<br>";



    $y = 15;

do{
    echo$y . "<br>";
    $y++;
}while($y <= 10);


echo "<br>";


$y = 15;

while($y < 10){
    echo $y;
    $y++;
}

echo "<br>";

echo "<br>";

for ($i=0; $i <= 100; $i+=2){
    echo $i . ",";
    
}

echo "<br>";


// for ($i=0; $i <= 100; $i+=2){
//     if($i % 2 == 0){
//         echo $i. ",";
//     }

    echo "<br>";

    for ($i = 0; $i <= 100; $i++ ){
        echo ($i % 2 == 0)? $i."," :null;
    } 
    


    

?>