<?php

require_once('sidebar.php');

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title> curd 5 </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
        <style type="text/css">
            *{
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                font-family: Verdana, Geneva, Tahoma, sans-serif;
            }
            body{
                width: 100%;
                height: 100vh;
                background-color: 5d6d7d;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            .container{
                max-width: 100%;
                width: 100%;
                background-color: #ffff ;
            }

        </style>

    </head>
    <body>
    <div class="container">
        <form method="post" action="">

            <input type="text" placeholder="style Name" class="data-insert" name="style_Name" value="">
            <input type="text" placeholder="po number" class="data-insert" name="po_number" value="">
            <input type="text" placeholder="color" class="data-insert" name="color" value="">
            <input type="text" placeholder="season" class="data-insert" name="season" value="">
            <input type="text" placeholder="Place Qty" class="data-insert" name="place_Qty" value="">
            <input type="submit" name="add_style" value="Add Style">

        </form>
    </div>
    </body>
</html>