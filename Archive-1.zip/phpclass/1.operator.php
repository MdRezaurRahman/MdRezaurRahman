<?php

//arithmatic operator
// + - * / % **


/* Assignment Operator
=
+=
-+
*=
/=
%=
*/

$x=5;
$x +=3;
echo $x;
echo "<br>";

//comparison operator

/*
==
===
!= not equal
<> not equal
!== value or data type not equal
>
<
>=
<=

 <=>
*/


$a = 5;
$b = "5";
$c = 5;

if ($a == $c)
echo "Amar Bangladesh" . "<br>";


/* increment and drecrement operator
++

--

*/

$m=6;

echo $m . "<br>";
echo ++$m . "<br>";
echo $m++ . "<br>";

echo --$m . "<br>";
echo $m-- . "<br>";
echo $m . "<br>";

$n=8;

++$n;
echo $n . "<br>";

/* Logical Operators

&&
and
||
or
xor
*/
 
$age_p1 = 24;
$age_p2 = 40;
if($age_p1 > $age_p2 && $age_p1 < 40 ){
    echo "I am good";
} else{
    echo "I am not ok"; 
}

echo "<br>";

$age_p1 = 24;
$age_p2 = 40;
if($age_p1 > $age_p2 || $age_p1 < 40 ){
    echo "I am good";
} else{
    echo "I am not ok"; 
}

echo "<br>";

$age_p1 = 24;
$age_p2 = 40;
if($age_p1 < $age_p2 xor $age_p1 < 40 ){
    echo "I am good";
} else{
    echo "I am not ok"; 
}


echo "<br>";


// conditional assigment operator
/*

?

??
*/


$city = "Dhaka";

if($city == "dh"){
    echo "Hi";

}else{
    echo "No";
}

echo "<br>";

$city = "Dhaka";

echo ($city == "Dhaka")? "Hi" :"Good Night";

echo "<br>";

$abc = 10;

if(isset($abc)){
    echo "Found";
}else {
    echo "no found";
}


echo "<br>";



if(isset($abc)){
    echo "$abc";
}else {
    echo "no found";
}
echo "<br>";

echo $abc ?? null ;







?>