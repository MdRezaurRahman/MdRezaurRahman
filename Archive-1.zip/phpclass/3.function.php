<?php
 
    function myFunc ($data ="Raisa & ", $lastName= " Rushni" ){
    echo $data ." ".$lastName . "<br>";
    }
 
    myFunc (" My Name is ", "Reza");
    myFunc (" Murad " , "Takla");
    myFunc ();
    myFunc ( " miss");
    myFunc ( null , "Raisa ");


echo"<br>";

    $dname1= "Raisa";
    $dname2= "Rushni";

    myFunc( $dname1, $dname2 );



    


?>