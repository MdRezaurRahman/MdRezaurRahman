


<!DOCTYPE html>
<html lang="en">
    <head>
        <title>form</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>


    <form action="insert.php" method="post" style="text-align:center;">

    <h1 style="color: red;"  > Pls Fill-Up Red Mark Writing </h1>

    Name: <input type="text" placeholder="Your Name" name="sname" value="<?=$s_name??null;?>">
    <?= $sname_err ?? null; ?>
    <br><br>

    Email: <input type="text" placeholder="Your Email" name="semail" value="<?=$s_email??null;?>">
    <?= $semail_err ?? null; ?>
    <br> <br>

    Gender:
    <input type="radio" name="gender" value="male" <?= (isset($s_gender) && $s_gender == "male")? "checked":null ?> > Male
    <input type="radio" name="gender" value="female" <?= (isset($s_gender) && $s_gender == "female")? "checked":null ?> > Female
    <?= $sgen_err ?? null; ?>
    <br> <br>

    Skills:
    <input type="checkbox" name="skills[]" value="html" >HTML
    <input type="checkbox" name="skills[]" value="css" >CSS
    <input type="checkbox" name="skills[]" value="bootstrap" >Bootstrap
    <input type="checkbox" name="skills[]" value="jquery" >JQuery
    <?= $s_skills_err ?? null; ?>
    <br> <br>

    <input type="submit" name="addstudent" value="Add Student">
    <br> <br>

    </form>
    </body>
</html>

<?= $save_dataform ?? null; ?>


