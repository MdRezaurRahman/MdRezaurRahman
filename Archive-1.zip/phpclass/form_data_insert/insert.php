<?php


if(isset($_POST['addstudent'])){
    $s_name = $_POST['sname'];
    $s_email = $_POST['semail'];
    $s_gender = $_POST['gender'] ?? null;
    $s_skills = $_POST['skills'] ?? null;



if(empty($s_name)){
    $sname_err = "<span style='color:red'> pls write Your Name </span>";
}elseif (!preg_match('/^[A-Za-z. ]*$/', $s_name)) {
    $sname_err = "<span style='color:red'> Invalid Name Format </span>";
}else{
    $sname_corr = $s_name;
}

if(empty($s_email)){
    $semail_err = "<span style= 'color:red' > Pls wrie your email </span>";
}elseif(!filter_var($s_email, FILTER_VALIDATE_EMAIL)){
    $semail_err = "<span style= 'color:red' > Invalid email Format </span>";
}else{
    $semail_corr = $s_email;
}

if(empty($s_gender)){
    $sgen_err = "<span style='color:red'> Pls select your gender </span>";
}else{
    $sgen_corr = $s_gender;
}

if(empty($s_skills)){
    $s_skills_err = "<span style='color:red'> Pls select your skills </span>";
}else{
    $sskills_corr = $s_skills;
}

if(isset($sname_corr) && ($semail_corr) && ($sgen_corr) && ($sskills_corr)){
    $save_dataform = " <span style='color:red;'> Save Successfully </span>";
}



$db_servername = "localhost";
$db_user = "root";
$db_password = "";
$db_database = "batch74";


$mysqli = new mysqli("localhost","root","","batch74");

if ($mysqli -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}

$mysqli -> query("INSERT INTO std_data (sname, semail, gender, skills) VALUES ('$s_name', '$s_email', '$s_gender', '$s_skills')");


// Print auto-generated id
Header( "Location: index.php" );
echo "New record has id: " . $mysqli -> insert_id;

$mysqli -> close();

}

?>