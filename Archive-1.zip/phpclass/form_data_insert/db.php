<?php

$db_servername = "localhost";
$db_user = "root";
$db_password = "";
$db_database = "batch74";


$db_connection = mysqli_connect($db_servername, $db_user, $db_password, $db_database);



?>