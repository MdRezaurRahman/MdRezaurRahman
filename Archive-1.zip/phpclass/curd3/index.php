
<?php

require_once('connection.php');

$insertmsg="";
$name="";
$email="";
$mnumber="";
$address="";
$state="";
$pin="";

if(isset($_GET['id'])){
    $id=$_GET['id'];
    $select=mysqli_query($conn, "SELECT * FROM cutoff ");
    $data=mysqli_fetch_assoc($select);

    $name=$data['name'];
    $email=$data['email'];
    $mnumber=$data['mnumber'];
    $address=$data['address'];
    $state=$data['state'];
    $pin=$data['pincode'];
}


if(isset($_POST['submit'])){
    // echo"<pre>";
    // print_r($_POST);
    $uname =$_POST['uname'];
    $email =$_POST['email'];
    $mnumber =$_POST['mnumber'];
    $address =$_POST['address'];
    $state =$_POST['state'];
    $pin =$_POST['pin'];

    $insert= mysqli_query($conn, "INSERT INTO `cutoff`(`name`, `email`, `mnumber`, `address`, `state`, `pincode`, `create_on`) VALUES ('$uname','$email','$mnumber','$address','$state','$pin', NOW())" );

    if($insert){
        $insertmsg= "Data Save Successfully";
    }else{
        $insertmsg= "Something Wrong";
    }

    }

?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <title> curd3 </title>

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
        <style type="text/css">
        *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            font-family: Verdana, sans-serif;
        }

        body{

            width: 100%;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #5d6d7d;
        }
        .container{
            max-width: 500px;
            width: 100%;
            background-color: #ffff;
        }
        .container form{
            width: 100%;
            padding: 30px;
        }
        .container form .data-insert{
            width: 100%;
            padding: 12px 10px;
            outline: none;
            border: 1px solid #111;
            margin: 8px 0px;
            cursor:pointer;
        }
        .container form .sub-btn{
            width: 100%;
            padding: 10px 30px;
            background-color: darkred;
            color: #ffff;
            font-size: lem;
            outline: none;
            border: 0;
            cursor: pointer;
        }

        .container h1{
            display: block;
            text-align: center;
            padding: 15px 10px;
        }

        </style>
    </head>

    <body>

  <div class="container">
<h1> Data Insert </h1>

<form action="" method="post">

    <input type="text" placeholder="your name" name="uname" class="data-insert" value="<?php echo$name;?>">

    <input type="email" placeholder="your email" name="email" class="data-insert" value="<?php echo $email;?>">

    <input type="text" placeholder="your mnumber" name="mnumber" class="data-insert" value="<?php echo $mnumber;?>">

    <input type="text" placeholder="your address" name="address" class="data-insert" value="<?php echo $address;?>">

    <input type="text" placeholder="your state" name="state" class="data-insert" value="<?php echo $state;?>">

    <input type="text" placeholder="your pin" name="pin" class="data-insert" value="<?php echo $pin;?>">

    <input type="submit" name="submit" class="sub-btn" value="Submit">

        <br><br>
        <span style="color:green" style="text-align: center;"> <?=$insertmsg;?> </span>
</form>
  </div>

    </body>
</html>