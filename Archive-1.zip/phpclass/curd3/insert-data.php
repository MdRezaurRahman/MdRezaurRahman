<?php

$conn=mysqli_connect('localhost', 'root', '', 'planning-2');



?>
