<?php

$conn=mysqli_connect('localhost', 'root', '', 'planning-2');

// if($conn){
//     echo"connection Successfully";
// }else{
//     echo "something Error";
// }

?>