<?php

require_once('connection.php');

if(isset($_GET['id'])){
    $id=$_GET['id'];

    $delete=mysqli_query($conn, "DELETE FROM cutoff WHERE id='$id'");
    if($delete){
    header("location:select.php");
    die();
    }

}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title> Data </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">

<style type="text/css">
    *{
        padding: 0;
        margin: 0;
        box-sizing: border-box;
        font-family: Verdana, sans-serif;
    }
    body{
        /* display: flex; */
        justify-content: center;
        align-items: center;
        width: 100%;
        height: 100vh;
        background-color: 5d6d7d;
    }
    table{
        border-collapse: collapse;
    }
    table th{
        background-color: royalblue;
        padding: 8px 10px;
        color: #fff;
    }
    .opt{
        background-color: orange;
        color: #fff;
        font-size: lem;
        padding: 0px;
        text-decoration: none;
    }

</style>
       
    
    </head>
    <body>
    
    <div class="container" >
        <table border="2px" cellpadding="0">
            <tr>
                <th>ID</th>
                <th> Name </th>
                <th> Email </th>
                <th> Phone Number </th>
                <th> Address </th>
                <th> State </th>
                <th> Zip Code </th>
                <th> Create Time </th>
                <th> Action </th>

            </tr>
            <?php
            require_once('connection.php');

            $select=mysqli_query($conn, "SELECT * FROM cutoff");
            $num=mysqli_num_rows($select);

            if($num>0){
                while($result=mysqli_fetch_assoc($select)){
                    echo"
                    <tr>
                    <td>".$result['id']." </td>
                    <td>".$result['name']." </td>
                    <td>".$result['email']." </td>
                    <td>".$result['mnumber']." </td>
                    <td>".$result['address']." </td>
                    <td>".$result['state']." </td>
                    <td>".$result['pincode']." </td>
                    <td>".$result['create_on']." </td>
                    <td> 

                    <a href='update.php?id=".$result['id']."' class='opt'> Update </a>
                    <a href='?id=".$result['id']."' class='opt'> Delete </a>

                    </td>


                    </tr>

                    ";
                }
            }

            ?>

        </table>
    </div>

    </body>

</html>