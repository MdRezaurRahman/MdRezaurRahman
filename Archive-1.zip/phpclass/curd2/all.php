<?php

require_once('./nav.php');

$select_query= "SELECT * FROM `cutoff_report`";
$select_data= $conn->query($select_query);



?>


<table border="2px" width="400" cellspaceing= "0" cellpadding="0">
    <tr style="text-align: center;">
        <td style="text-align: center;" > S.No </td>
        <td> Style</td>
        <td> PO Number </td>
        <td> Action </td>
    </tr>

        <?php
        $sl=1;
        while ($selectdata= $select_data->fetchObject()){

        ?>

        <tr>
            <td> <?= $sl; ?> </td>
        <td> <?=$selectdata->name;?> </td>
        <td> <?=$selectdata->city;?> </td>
        <td>
            <a href="./update.php?id=<?=$selectdata->id;?>"> Update </a>
            <a href="./delete.php?=<?=$selectdata->id;?>"> Delete </a>
        </td>
        </tr>

        <?php $sl++; } ?>


</table>
