<?php

require_once('./nav.php');

if(!isset($_GET['id'])){
header('location: all.php');
}else{
    $id=$_GET['id'];
}

if(isset($_POST['del123']) && $_SERVER['REQUEST_METHOD'] === 'POST'){
    $del_id = $_POST["id"];

    $del_query = "DELETE FROM `cutoff_report` WHERE id = :id";

    if(mysqli_query($con,$del_query)){
        $deletemsg= "<span style='color:red'> Delete Successfully </span>";
    }
}

?>

<h2> Do You Want to Really Delete?? </h2>

<form action="<?= $_SERVER['PHP_SELF'].'?id='.$id ?>" method="post" style="display: inline;">
    <input type="hidden" name="id" value="<?= $id;?>">
    <input type="submit" name="del123" value="Yes">

</form>

<a href="./update.php">
    <button> No </button>
</a>

<?=$deletemsg;?>


<!-- 
<?php

require_once('./nav.php');

if(isset($_GET['id'])){
    header("location: all.php");
}else{
    $id = $_GET['id'];
}

if(isset($_POST['del123']) && $_SERVER['REQUEST_METHOD'] === 'POST'){
    $del_id= $_POST['id'];

    $del_query= "DELETE FROM `cutoff_report` WHERE id=:id";
    $predel= $conn->prepare($del_query);
    $delete = $predel->execute([ ':id'=> $del_id ]);
    if($delete){
        $delmsg="Deleted";
    }
}

?>

<form action="<?= $_SERVER['PHP_SELF']."?id=".$id ?>" method="post" style="display: inline;">
    <input type="hidden" name="id" value="<?= $id ?>">
    <input type="submit" value="Yes" name="del123" >

</form>

<a href="./all.php">
    <button type=""> No </button>
</a>

<br> <br>
<?=$delmsg;?> -->