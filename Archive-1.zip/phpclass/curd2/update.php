<?php

require_once('./nav.php');

if(!isset($_GET['id'])){
header ('location: all.php');
}else{
    $id=$_GET['id'];
}

// $upname=$upcity=null;

$select_query= $conn->query("SELECT * FROM `cutoff_report`WHERE id=$id");
$predata = $select_query->fetchObject();



if(isset($_POST['update_style']) || $_SERVER['REQUEST_METHOD'] === 'POST'){
    $name= safe($_POST['name']);
    $city= safe($_POST['city']);

if(empty($name)){
    $errmsg="<span style='color:red' > Pls write your Name </span>";
}elseif(!preg_match("/^[A-Za-z. ]*$/", $name)){
    $errmsg="<span> Invalid Name </span>";
}else {
      $corrname= $name;
  }


if(empty($city)){
    $errcity="<span style='color:red'> Pls write your City </span>";
}elseif(!preg_match("/^[A-Za-z0-9. ]*$/", $city)){
    $errcity="<span> Invalid Name </span>";
}else{
    $corrcity= $city;
}

if(isset($corrname) && isset($corrcity)){
   $update_query ="UPDATE `cutoff_report` SET `name` = :name, `city` = :city WHERE id=:id";
    $updata= $conn->prepare($update_query);
    $updata->execute([
        ':name'=>$corrname,
        ':city'=>$corrcity,
        ':id'=>$id
    ]);

    if($updata){
        $Updatemsg= "<span style='color:green'> Update Successfully </span>";
    $upname=$corrName;
    $upcity=$corrCity;

    }else{
        $Updatemsg= "<span style='color:green'> Something Wrong </span>";
    }
}

}

function safe ($data){
    $data= htmlspecialchars($data);
    $data= trim($data);
    $data= stripslashes($data);
    return $data;
}



?>

<form action="<?=$_SERVER['PHP_SELF'].'?id='.$id ?>" method="post">

<input type="text" placeholder="Your Name" name="name" value="<?= $upname ?? $predata->name;?>">
<?=$errmsg??null?>
<br> <br>
<input type="text" placeholder="Your City" name="city" value="<?= $upcity ?? $predata->city;?>">
<?=$errcity??null?>
<br> <br>
<input type="submit" name="update_style" value="Update Style">
<br> <br>
<?=$Updatemsg??null?>

</form>