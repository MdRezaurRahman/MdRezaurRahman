<?php

require_once('./nav.php');

if(isset($_GET['id'])){
    header("location: all.php");
}else{
    $id = $_GET['id'];
}





if(isset($_POST['del123'])){
    $id= $_POST['id'];

    $del_query= "DELETE * FROM `cutoff_report` WHERE id='$id'";
    if($del_query){
        $delMsg= "Deleted";
    }
}

?>

<form action="" method="post" style="display: inline;">
<a href="all.php">NO</a>
<input type="hidden" name="id" value="<?=$id;?>">

<input type="submit" name="del123" value="Yes">
<br> <br>
<?=$delMsg??null?>

</form>
