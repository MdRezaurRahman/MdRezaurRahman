
<?php
require_once('./nav.php');

if(isset($_POST['add_style']) || $_SERVER['REQUEST_METHOD'] === 'POST'){
    $name= safe($_POST['name']);
    $city= safe($_POST['city']);

if(empty($name)){
    $errmsg="<span style='color:red' > Pls write your Name </span>";
}elseif(!preg_match("/^[A-Za-z. ]*$/", $name)){
    $errmsg="<span> Invalid Name </span>";
}else {
      $corrname= $name;
  }


if(empty($city)){
    $errcity="<span style='color:red'> Pls write your City </span>";
}elseif(!preg_match("/^[A-Za-z0-9. ]*$/", $city)){
    $errcity="<span> Invalid Name </span>";
}else{
    $corrcity= $city;
}

if(isset($corrname) && isset( $corrcity)){
    $insert_data =" INSERT INTO `cutoff_report` (`name`,`city`) VALUES ('$name', '$city') ";
    $insert_query=$conn->query($insert_data);
    if( $insert_query){
        $succmsg= "<span style='color:green'> Save Successfully </span>";
    }else{
        $succmsg= "<span style='color:green'> Something Wrong </span>";
    }
}

}


function safe ($data){
    $data= htmlspecialchars($data);
    $data= trim($data);
    $data= stripslashes($data);
    return $data;
}


$select_query= "SELECT * FROM `cutoff_report`";
$select_data= $conn->query($select_query);


?>


<form action="" method="post">

<input type="text" placeholder="your name" name="name"  >
<?=$errmsg??null?>
<br> <br>
<input type="text" placeholder="your city" name="city" >
<?=$errcity??null?>
<br> <br>
<input type="submit" name="add_style" value="Add Style">
<br> <br>
<?=$succmsg??null?>

</form>

