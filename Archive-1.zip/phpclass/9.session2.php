<?php
session_start();

if(isset($_SESSION['rname']) && isset($_SESSION['gender'])){
    echo "Login Successfully";
}else{
    echo "You are Logout";
}





?>