
<?php

if(isset($_POST['addstudent'])){
    $s_name = $_POST['sname'];
    $s_email = $_POST['semail'];
    $s_gender = $_POST['gender'] ?? null;
    $s_skills = $_POST['skills'] ?? null;



if(empty($s_name)){
    $sname_err = "<span style='color:red'> pls write Your Name </span>";
}elseif (!preg_match('/^[A-Za-z. ]*$/', $s_name)) {
    $sname_err = "<span style='color:red'> Invalid Name Format </span>";
}else{
    $sname_corr = $s_name;
}

if(empty($s_email)){
    $semail_err = "<span style= 'color:red' > Pls wrie your email </span>";
}elseif(!filter_var($s_email, FILTER_VALIDATE_EMAIL)){
    $semail_err = "<span style= 'color:red' > Invalid email Format </span>";
}else{
    $semail_corr = $s_email;
}

if(empty($s_gender)){
    $sgen_err = "<span style='color:red'> Pls select your gender </span>";
}else{
    $sgen_corr = $s_gender;
}

if(empty($s_skills)){
    $s_skills_err = "<span style='color:red'> Pls select your skills </span>";
}else{
    $sskills_corr = $s_skills;
}

if(isset($sname_corr) && ($semail_corr) && ($sgen_corr) && ($sskills_corr)){
    $save_dataform = " <span style='color:red;'> Save Successfully </span>";
}



}

?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <title>form</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>


    <form action="" method="post" style="text-align:center;">

    <h1 style="color: red;"  > Pls fill-up red mark writing </h1>

    Name: <input type="text" placeholder="Your Name" name="sname" value="<?=$s_name??null;?>">
    <?= $sname_err ?? null; ?>
    <br><br>

    Email: <input type="text" placeholder="Your Email" name="semail" value="<?=$s_email??null;?>">
    <?= $semail_err ?? null; ?>
    <br> <br>
    Gender:
    <input type="radio" name="gender" value="male" <?= (isset($s_gender) && $s_gender == "male")? "checked":null ?> > Male
    <input type="radio" name="gender" value="female" <?= (isset($s_gender) && $s_gender == "female")? "checked":null ?> > Female
    <?= $sgen_err ?? null; ?>
    <br> <br>
    Skills:
    <input type="checkbox" name="skills[]" value="html" <?= (isset($s_skills) && in_array('html',$s_skills ))? "checked":null ?> >HTML
    <input type="checkbox" name="skills[]" value="css" <?= (isset($s_skills) && in_array('css' ,$s_skills ))?"checked":null ?> >CSS
    <input type="checkbox" name="skills[]" value="bootstrap"  <?= (isset($s_skills) && in_array ('bootstrap' ,$s_skills))?"checked":null ?> >Bootstrap
    <input type="checkbox" name="skills[]" value="jquery"  <?= (isset($s_skills) && in_array('jquery', $s_skills))? "checked":null ?>>JQuery
    <?= $s_skills_err ?? null; ?>
    <br> <br>

    <input type="submit" name="addstudent" value="Add Student">
    <br> <br>
    <?= $save_dataform ?? null; ?>
    </form>
    </body>
</html>




<?php

if(isset($s_skills)) {
    ?>

    <pre>
    <?php print_r($s_name);?>
    </pre>

    <pre>
    <?php print_r($s_email);?>
    </pre>

    <pre>
    <?php print_r($s_gender);?>
    </pre>

    <pre>
    <?php print_r($s_skills);?>
    </pre>

<?php
}
?>
