<?php


// $conn = mysqli_connect('localhost','root', '', 'cutting' );

// if ($conn){
//     echo "Connected";
// }else{
//     echo "Not Connected";
// }

// $host = "localhost";
// $user = "root";
// $pass = "";
// $db = "sewing";

// $connection = mysqli_connect ($host, $user, $pass, $db);


// if ($connection){
//     echo "Connected";
// }else{
//     echo "Not Connected";
// }

// define("host", "localhost");
// define("user","root");
// define("pass","");
// define("db","sewing");

// $conn = mysqli_connect(host, user, pass, db);


// if ($conn === false){
//     die("ERROR: Could not connect. " . mysqli_connect_error());
// }
//     echo "Connection Successfully". mysqli_get_host_info($conn);


//     mysqli_close($conn);


// // Check connection
// if($link === false){
//     die("ERROR: Could not connect. " . mysqli_connect_error());
// }

// // Print host information
// echo "Connect Successfully. Host info: " . mysqli_get_host_info($link);






// class database {
//     public $connection;
//     public $hostname = "localhost";
//     public $dbname = "sewing";
//     public $dbuser = "root";
//     public $pass = "";

//     public function __construct(){
//         $this->connection = new PDO("mysql:host= $this->hostname;
//         dbname=$this->dbname" , $this->dbuser, $this->pass);
//         if($this->connection){
//                echo 'PDO database connected';
//         }else{
//             echo "error";
//         }
//     }

// }



// $conne = new PDO ("mysql: host = localhost; sewing", "root", "");

// if ($conne){
//     echo "PDO Connected";
// }else{
//     echo "Not Connected";
// }










// $conne = new PDO ("mysql: host = localhost; sewing", "root", "");

// if ($conne){
//     echo "PDO Connected";
// }else{
//     echo "Not Connected";
// }






$host = "localhost";
$user = "root";
$pass = "";
$db = "sewing";

try {
    $connec = new PDO("mysql:host=$host; $db ", $user, $pass);
    // set the PDO error mode to exception
    $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "PDO Connection successfully<br>";
  } catch(PDOException $e) {
    echo $sql . "<br>" . $e->getMessage();
  }
  $connec = null;







?>

