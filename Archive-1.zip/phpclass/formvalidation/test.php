
<?php

if(isset($_POST['addstu11'])){
    $s_name = $_POST['sname'];
    $s_email =$_POST['semail'];
    $s_gender = $_POST['gender'];
    $sskills = $_POST['skills'];

if(empty($s_name)){
    $sname_err = " <span style='color:red' > Pls Write your Name </span> ";
}elseif (!preg_match('/^[A-Za-z. ]*$/', $s_name)){
    $sname_err = " <span style='color:red' > Invalid Name format </span> ";
}else{
    $sname_corr = $s_name;
}

if(empty($s_email)){
    $semail_err = " <span style='color:red'> pls write your email </span>";
}elseif(!filter_var($s_email, FILTER_VALIDATE_EMAIL)){
    $semail_err = " <span style='color:red'> Invalid Email Format </span>";
}else{
    $semail_corr = $s_email;
}

if(empty($s_gender)){
    $sgen_err = "<span style='color:red' > pls select your gender </span>";
}else{
    $sgen_corr = $s_gender;
}

if(empty($sskills)){
    $sskill_err = "<span style='color:red' > pls select your skills </span>";
}else{
    $sskill_corr = $sskills;
}

if(isset($sname_corr) && ($semail_corr) && ($sgen_corr) && ($sskill_corr)){
    $save_data = " Your Name: $sname_corr <br> Your Email: $semail_corr <br> Your Gender: $sgen_corr <br> Your Skill: ".implode(", ", $sskill_corr );
}

}


?>




<!DOCTYPE html>
<html lang="en">
    <head>
        <title> form validation </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">

    </head>
    <body>

    <form action="" method="POST" style="text-align: center;" >

    <h1 style="color: red;"> Pls fill-up red colom form </h1>

        Name:<input type="text" placeholder="Your Name" name="sname" value="<?=$s_name??null;?>">
        <?= $sname_err ?? null; ?>
        <br> <br>

        Email:<input type="text" placeholder="Your Email" name="semail" value="<?=$s_email??null;?>">
        <?= $semail_err?? null; ?>
        <br><br>

       Gender:
        <input type="radio" name="gender" value="male" <?=(isset($s_gender) && $s_gender == "male")? "checked":null ?> >Male
        <input type="radio" name="gender" value="female" <?=(isset($s_gender) && $s_gender == "female")? "checked":null ?> >Female
        <input type="radio" name="gender" value="others" <?=(isset($s_gender) && $s_gender == "others")? "checked":null ?> >Others
        <?=  $sgen_err?? null; ?>
        <br> <br>

        Skills:
        <input type="checkbox" name="skills[]" value="html" <?= (isset($sskills) && in_array('html', $sskills))? "checked":null ?> > HTML
        <input type="checkbox" name="skills[]" value="css" <?= (isset($sskills) && in_array('css', $sskills))? "checked":null ?> > CSS
        <input type="checkbox" name="skills[]" value="bootstrap" <?= (isset($sskills) && in_array('bootstrap', $sskills))? "checked":null ?> > Bootstrap
        <input type="checkbox" name="skills[]" value="jquery" <?= (isset($sskills) && in_array('jquery', $sskills))? "checked":null ?> > JQuery
        <?= $sskill_err?? null; ?>
        <br> <br>

        <input type="submit" name="addstu11" value="Add Student">
        <br>
        <br>

    </form>
    <h3 style="color: green;" > <?= $save_data ?? null; ?></h3>

</body>
</html>




<?php
if(isset($s_name)){
    ?>
<pre>
    <?php print_r($s_name); ?>
</pre>

<pre>
    <?php print_r($s_email); ?>
</pre>

<pre>
    <?php print_r($s_gender); ?>
</pre>

<pre>
    <?php print_r($sskills); ?>
</pre>


<?php
}
?>
