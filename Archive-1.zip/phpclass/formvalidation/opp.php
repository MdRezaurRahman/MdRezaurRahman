<?php 

    class myclass{
        public string $area ="Dhanmondi";
        public int $age = 35;
        public array $skils = ['html', 'css', 'js', 'php', 'mysql'];

    }


    $myobj = new myClass;
    echo $myobj->area. "<br>".$myobj->age;
    echo $myobj->skills[1];

    foreach($myobj->skills as $skills){

    echo $skills."<br>";
}


?>