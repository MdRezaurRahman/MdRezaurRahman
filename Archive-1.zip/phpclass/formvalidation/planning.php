
<?php


if(isset($_POST['cutoff_report'])){
    $style_name = $_POST['style_name'];
    $po_number = $_POST['po_number'];
    $color = $_POST['color'];
    $season = $_POST['season'];
    $booked_placed_qty = $_POST['booked_placed_qty'];
    $placed_qty = $_POST['placed_qty'];
    $final_Place_qty = $_POST['final_Place_qty'];
    $product_section = $_POST['product_section'];
    $product_dpt = $_POST['product_dpt'];
    $opd_week_name = $_POST['opd_week_name'];
    $tod_month_name = $_POST['tod_month_name'];
    $tod_week_name = $_POST['tod_week_name'];
    $speed_production = $_POST['speed_production'];

if(empty($style_name)){
    $style_err = "pls write style name";
}

}


?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <title> planning </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">

        <style>
        .tr,td{
            height: 2px;
            padding: 5px;
            text-align: center;
        }

        </style>
    </head>
    <body>

<form action="" method="POST">
<br>
<table border="2px solid black" style="padding:2%">

<tr>

<td> Serial No: </td>
<td> Style Name: </td>
<td> PO Number: </td>
<td> Color </td>
<td> Season </td>
<td> Booked & Placed Qty: </td>
<td> Placed Qty: </td>
<td> Final Place Qty: </td>
<td> Product Section: </td>
<td> Product Dpt: </td>
<td> OPD Week Name: </td>
<td> TOD Month Name: </td>
<td> TOD Week Name: </td>
<td> Speed Production: </td>
<td> Create Date & Time: </td>
<td> Action </td>
<td> Action </td>

</tr>

<tr>

<td> <input type="button" name="id" value="1"> </td>
<td> <input type="text" name="style_name" value="<?=$style_name??null;?>"> 
<?=$style_err??null; ?>
</td>
<td> <input type="text" name="po_number" value=""> </td>
<td> <input type="text" name="color" value=""> </td>
<td> <input type="text" name="season" value=""> </td>
<td> <input type="text" name="booked_placed_qty" value=""> </td>
<td> <input type="text" name="placed_qty" value=""> </td>
<td> <input type="text" name="final_Place_qty" value=""> </td>
<td> <input type="text" name="product_section" value=""> </td>
<td> <input type="text" name="product_dpt" value=""> </td>
<td> <input type="text" name="opd_week_name" value=""> </td>
<td> <input type="text" name="tod_month_name" value=""> </td>
<td> <input type="text" name="tod_week_name" value=""> </td>
<td> <input type="text" name="speed_production" value=""> </td>
<td> <input type="text" name="create_date_time" value=""> </td>
<td> <input type="button" name="season" value="Edit"> </td>
<td> <input type="button" name="season" value="delete"> </td>

</tr>

<br>
<tr>
<td>
    <input type="button" name="cutoff_report" value="Cutoff Process">
</td>
</tr>

</table>


</form>

    </body>
</html>


<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "planning_data";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


// prepare and bind
$stmt = $conn->prepare("INSERT INTO `cutoff_data` (`id`, `style_name`, `po_number`, `color`, `season`, `booked_placed_qty`, `placed_qty`, `final_Place_qty`, `product_section`, `product_dpt`, `opd_week_name`, `tod_month_name`, `tod_week_name`, `speed_production`, `create_date_time`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
$stmt->bind_param("sss", $style_name, $po_number, $color, $booked_placed_qty, $placed_qty, $final_Place_qty, $product_section, $product_dpt, $opd_week_name, $tod_month_name, $tod_week_name, $speed_production );


// set parameters and execute

$style_name = "";
$po_number = "";
$color = "";
$season = "";
$booked_placed_qty = "";
$placed_qty = "";
$final_Place_qty = "";
$product_section = "";
$product_dpt = "";
$opd_week_name = "";
$tod_month_name = "";
$tod_week_name = "";
$speed_production = "";

$stmt->execute();

echo "New records created successfully";

$stmt->close();
$conn->close();

?>
