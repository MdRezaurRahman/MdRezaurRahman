<?php

require('fpdf.php');

$pdf=new FPDF();
$pdf->AddPage();
$pdf->setFont('Arial','B', '18');
$pdf->Cell(40,10,'Thsi is text');
$pdf->output();


?>