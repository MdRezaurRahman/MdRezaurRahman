<?php $deg=rand(180,180); ?>


<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Random transform:rotate</title>
        <style type="text/css">
            #memo {
                width:5em; word-wrap:break-word; margin:2em;
                font:700 3em/1.2 'myriad pro', sans-serif;
                transform:rotate(<?php echo $deg; ?>deg);
                -o-transform:rotate(<?php echo $deg; ?>deg);
                -moz-transform:rotate(<?php echo $deg; ?>deg);
                -webkit-transform:rotate(<?php echo $deg; ?>deg);
            }
        </style>
    </head>
    <body>
        <div id="memo">Hello</div>
    </body>
</html>