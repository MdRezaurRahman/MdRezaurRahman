<?php
require_once('dbcon.php');


 $selectdata = $conn->query("SELECT * FROM `cutoff_report` ")

// $sql = "SELECT id, style_name, po_number FROM cutoff_report";
// $result = $conn->query($sql);

// if ($result->num_rows > 0) {
//   echo "<table border='2px'>
//   <tr>
//   <th>ID</th>
//   <th>Name</th>
//   </tr>";
//   // output data of each row
//   while($row = $result->fetch_assoc()) {
//     echo "<tr><td>".$row["id"]."</td><td>".$row["style_name"]." ".$row["po_number"]."</td></tr>";
//   }
//   echo "</table>";
// } else {
//   echo "0 results";
// }
// $conn->close();

?>


<table border="2px" >

<tr style="text-align: center;">
    <td> S.No </td>
    <td> Style </td>
    <td> PO Number </td>
    <td> Action </td>
</tr>


<?php
$serial=1;
while($selec= $selectdata->fetch_assoc()){

?>

<tr>
<td> <?= $serial?> </td>
<td> <?= $selec['style_name'];?></td>
<td> <?= $selec['po_number'];?></td>
<td>
    <a href="./update.php"> Update </a>
    <a href="delete.php"> Delete </a>
</td>

</tr>

<?php $serial++; } ?>

</table>