<?php

require_once('./dbcon.php');

if(isset($_GET['id'])){
    header("location: select.php");
}else{
    $id = $_GET['id'];
}


if(empty($style)){
    $styleErr = "<span style='color:red'; > Pls fill up Blank Fild </span>";
}else{
    $style = test_input($_POST['style_name']);
}

    if(empty($po_number)){
        $poErr = "<span style='color:red'; > Pls fill up Blank Fild </span>";
    }else{
     $po_number = test_input($_POST['po_number']);
    }

    if(isset($style) && isset($po_number)){
        $update_query = "UPDATE 'cutoff_report' SET `style_name`= :$style, `po_number` = : $po_number WHERE id= :id";

        $updatedata= $conn->prepare($update_query);

        $updata=$updatedata->execute([
            ':style_name'=>$style,
            ':po_number'=>$po_number,
            ':id'=>$id

        ]);

        if($updata){
            $succmsg = "<span> Data Update Successfully </span>";
        }else{
            $succmsg = "<span> Data Update Successfully </span>";
        }

        }



?>


<form action="" method="post">

Style_name: <input type="text" placeholder="style name" name="style_name" value="<?=$selec['style_name'];?>">
<?= $styleErr ?? null; ?>
<br><br>

po number: <input type="text" placeholder="po number" name="po_number" value="<?=$selec['po_number'];?>">
<?= $poErr ?? null; ?>
<br><br>

<input type="submit" name="update_style" value="Update Style">

</form>
