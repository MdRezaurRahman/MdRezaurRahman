<?php
require_once('dbcon.php');

$styleErr = $poErr = "";
$style = $po = "";

if($_SERVER ["REQUEST_METHOD"] == "POST"){

    if(empty($_POST['style_name'])){
        $styleErr = "<span style='color:red'; > Pls fill up Blank Fild </span>";
    }else{
        $style = test_input($_POST['style_name']);
    }

    if(empty($_POST['po_number'])){
        $poErr = "<span style='color:red'; > Pls fill up Blank Fild </span>";
    }else{
     $po_number = test_input($_POST['po_number']);
    }

}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
 }


?>


<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">

Style_name: <input type="text" placeholder="style name" name="style_name" value="">
<?= $styleErr ?? null; ?>
<br><br>

po number: <input type="text" placeholder="po number" name="po_number" value="">
<?= $poErr ?? null; ?>
<br><br>

<input type="submit" name="style_add" value="Style Process">

</form>



<?php

$insertdat= "INSERT INTO cutoff_report (style_name, po_number ) Values ('$style', '$po_number') ";

if($conn->query($insertdat) === TRUE){
    echo "Data Saved". $last_id;
}else{
    echo "Something Error". $insertdat . $conn ->error;
}

$conn-> close();

?>