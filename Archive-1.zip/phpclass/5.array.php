<?php

// index array

$city= array('Dhaka', 'Barishal', 'Cumilla');

echo $city[2];

echo "<br>";


echo "<pre>";
print_r($city);
echo "</pre>";



$person = ['Reza', 34, 'Barguna', 'Engineer'];

echo "<pre>";
print_r($person);
echo "</pre>";

$person[]= "Married";

echo "<pre>";
print_r($person);
echo "</pre>";

echo count($person);

echo "<br>";


echo $person[0]. " ". $person [1]." ".$person[2]." ".$person[3]." ".$person[4] ;


echo "<br>";


$x= 0;

while ($x < count($person)){
    echo $person [$x]. " ";
    $x++;
}

echo "<br>";

for ($i=0; $i < count($person); $i++){

    echo $person [$i]. " ";
}

echo "<br>";

foreach ($person as $item){
    echo $item." "; 
}

echo "<br>";

//Associative array

$student = ['Name' => 'Asif Abir' , 'Age'=> 35, 'City'=> 'Dhaka', 'Profession'=> 'Engineer', 'Sstatus' => false];
echo $student['name']."<br>";
$student ['M: Status']= "maried";

echo "<pre>";
print_r($student);
echo "</pre>";

echo count($student)."<br>";

foreach ($student as $dindex => $sData){
    if($dindex == "Sstatus"){$dindex = "Student Status";}
    if($dindex == "mstatus"){$dindex = "marital Status";}
    if($sData == null ){$sData = "Not Student";}
    echo ucwords($dindex)." : ".ucwords($sData)."<br>";
    
    
}

echo "<br>";

$x= ['Name' => 'takla murad' , 'age' => 60, ];
foreach ($x as $iName => $value){
    echo ucwords($iName)." : ".ucwords($value). " <br>";
}


echo "<br>";


//multidimentional Array

$students = [
    ['pranto', 'Male', 'Dhaka'],
    ['Reza', 'Male', 'Dhaka'],
    ['Mostafiz', 'Male', 'Dhaka'],
    ['Tanvir', 'Male', 'Dhaka'],
    ['shamsromana', 'Female', 'Dhaka']
];

echo "<pre>";
print_r($students);
echo "</pre>";
echo $students['0']['0']."<br>";

echo count($students);


echo "<br>";echo "<br>";



for($a=0; $a <count($students); $a++){
    for ($b = 0; $b < count($students[$a]); $b++){
        echo $students [$a] [$b] ." ";
    }
    echo "<br>";
}


echo "<br>";echo "<br>";


foreach ($students as $idata){
    foreach ($idata as $p1data){
        echo $p1data." ";
    }
    echo "<br>";
}


echo "<br>";

$programmers = [
    'name' => ['reza', 'raisa', 'rushni', 'marjana'],
    'age' => ['34', '8', '4', '26'],
    'profession'=> ['engineer', 'student', 'student', 'hwife'],
    'city'=> ['Barishal','Barishal','Barishal','Barishal', ]

];

for ($l= 0; $l < count($programmers); $l++ ){
    foreach ($programmers as $fdata => $p2data){
        echo ucwords($fdata)." : ".ucwords(($p2data)[$l])." <br> ";
    }
    echo "<br>";
}

 



?>