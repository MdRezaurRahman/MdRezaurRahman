<?php

session_start();


$_SESSION['rname'] = "reza"."<br>";
$_SESSION['gender'] = "male"."<br>";
$_SESSION['profe'] = "admin"."<br>";

header("location: ./session2.php");






?>