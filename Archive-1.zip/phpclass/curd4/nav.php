<table border="2px" >
<form style="display: inline;">

<tr>
    <td><a href="index.php">Main Page</a></td>
    <td><a href="insert.php"> Add Style</a></td>
    <td><a href="select.php"> All Data</a></td>
</tr>

</form>
</table>