<?php 
require_once('./nav.php');
require_once('dbcon.php');

if(isset($_GET['id'])){
    $id=$_GET['id'];
    $delete= mysqli_query($conn, "DELETE FROM `style_data` WHERE id='$id' ");
    if($delete === TRUE){
        $delemsg="Deleted";
        header("location: select.php");
    }else{
        $delerror="Sosmething Wrong";
    }
}




// if(isset($_GET['id'])){
//     $id=$_GET['id'];

//     $delete=mysqli_query($conn, "DELETE FROM cutoff WHERE id='$id'");
//     if($delete){
//     header("location:select.php");
//     die();
//     }

// }

?>
