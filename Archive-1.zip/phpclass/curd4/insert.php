
<?php
require_once('./nav.php');

require_once('dbcon.php');

if(isset($_POST['add_style'])){

    $style=$_POST['style'];
    $po=$_POST['po_number'];
    $color=$_POST['color'];

    $inser_data= mysqli_query($conn, "INSERT INTO `style_data`(`style_name`, `po_number`, `color_name`, `time`) VALUES ('$style','$po','$color',NOW())");

    if($inser_data){
        $inmsg="<span style='color:green'> Data Insert Successfully </span>";
    }else{
        $inmsg= "<span style='color:green'> Something Wrong </span>";
    }
}


// if (isset($_Post['submit'])) {
//     $style_name= $_Post['style'];
//     $po_number= $_Post['po_number'];
//     $color= $_Post['color'];

//     $insert=mysqli_connect($conn, "INSERT INTO `style_data`(`style_name`, `po_number`, `color_name`) VALUES ('$style_name','$po_number','$color')");

//     if($insert){
//         $insertMsg= "Insert Successfully";
//     }else{
//         $insertMsg="something Wrong";
//     }
// }



// if(isset($_POST['submit'])){
//     // echo"<pre>";
//     // print_r($_POST);
//     $style =$_POST['style'];
//     $ponumber =$_POST['po_number'];
//     $color =$_POST['color'];

//     $insert= mysqli_query($conn, "INSERT INTO `style_data`(`style_name`, `po_number`, `color_name`) VALUES ('$style','$ponumber','$color')");

//     if($insert){
//         $insertmsg= "Data Save Successfully";
//     }else{
//         $insertmsg= "Something Wrong";
//     }

//     }

?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <title> Data insert </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>

    

<table border="2px" width="600px">

<form action="" method="post">

<tr>
<td> Style Name </td>
<td><input type="text" placeholder="style Name"  name="style"></td>
</tr>
<br> <br>

<tr>
<td> PO Number </td>
<td><input type="text" placeholder="PO Number"  name="po_number" ></td>
</tr>

<br><br>
<tr>
<td> Color Name </td>
<td><input type="text" placeholder="color"  name="color" ></td>
</tr>

<br> <br>

   <tr>
   <td> <input type="submit" name="add_style" value="Add Style"></td>
   </tr>
    <br> <br>
   <?=$inmsg; ?>

</form>

</table>
    </body>
</html>
