<?php

$conn=mysqli_connect('localhost','root','','planning-2');

// if($conn){
//     echo "connected";
// }

?>