<?php
require_once('./nav.php');

require_once('dbcon.php');

$inmsg="";
$style="";
$po="";
$color="";

if(isset($_GET['id'])){
    $id=$_GET['id'];

    $select=mysqli_query($conn, "SELECT * FROM style_data WHERE id='$id'");
    $data=mysqli_fetch_assoc($select);

    $style_name =$data['style_name'];
    $po_number =$data['po_number'];
    $color_name =$data['color_name'];

}

if(isset($_POST['update_style'])){
    // echo"<pre>";
    // print_r($_POST);
    $style =$_POST['style'];
    $po_number =$_POST['po_number'];
    $color =$_POST['color'];

    if(isset($_GET['id'])){
        $update=mysqli_query($conn, "UPDATE `style_data` SET `style_name`='$style',`po_number`='$po_number',`color_name`='$color' WHERE id='$id'");

        if($update === TRUE){
            $updatemsg="Updated";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title> Show Data </title>

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>

    <div class="container">

<form action="" method="post">
<table bordeer="2px">

<tr>
    <td>Style Name</td>
        <td><input type="text" placeholder="style Name"  name="style" value="<?= $style_name;?>"> </td>
    </tr>
<br> <br>
    <tr>
    <td> PO Number </td>
    <td> <input type="text" placeholder="PO Number"  name="po_number" value="<?=$po_number;?>"> </td>
    </tr>
    <br><br>
    <tr>
    <td> Color Name </td>
    <td><input type="text" placeholder="color"  name="color" value="<?=$color_name;?>"></td>
    </tr>
    <br> <br>
       <tr>
       <td> <input type="submit" name="update_style" value="Update Style"></td>
       </tr>
</table>
        <br> <br>
       <?=$updatemsg; ?>
</form>
    </body>
</html>