<?php 
require_once('./nav.php');
require_once('dbcon.php');

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Show Data </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>

    <table border="2px" width="700px">

    <tr>
    <td> S.No </td>
    <td> Style Name </td>
    <td> PO Number </td>
    <td> Color </td>
    <td> Create Time </td>
    <td> Action </td>
    </tr>
    <?php

    $seledata= mysqli_query($conn, "SELECT * FROM style_data");
    $data=mysqli_num_rows($seledata);

    if($data>0){
        $sl=1;
        while($selresult= mysqli_fetch_assoc($seledata)){
            echo"
        <tr>
        <td> ".$selresult['id']."</td>
        <td> ".$selresult['style_name']."</td>
        <td> ".$selresult['po_number']."</td>
        <td> ".$selresult['color_name']."</td>
        <td> ".$selresult['time']."</td>
        <td>
        <a href='update.php?id=".$selresult['id']."'> Update </a>
        <a href='delete.php?id=".$selresult['id']."'> Delete </a>
        </td>
        
        </tr>
        ";

       $sl++; }

    }

    ?>

    </table>


    </body>
</html>

