<?php

// $age=15;
// if($age >= 12){
//     echo"I am ok";
// }elseif($age >= 20){
//     echo "i am not ok";
// }elseif($age >= 10){
//     echo "i am baby";
// }

// echo " <br>";

// $age =11;
// switch ($age ){
//     case "10";
// echo " i am baby";
// break;

// default:
// echo " not Match";
// break;

// }


// echo "<br>";

$age = 15;

if ($age <= 12 ){
    echo "you are baby";
}elseif($age <= 19){
    echo "You are Teenager";
}elseif($age <= 29){
    echo "You are Young";
}elseif($age <= 49){
    echo "You are widdle aged person";
}elseif($age <= 55){
    echo "you are Old Person";
}else{
    echo "He is not in the world";
}

echo "<br>";
echo "<br>";

$age= 20;

switch ($age ){
    case ($age <= 12);
    echo " You are Baby";
    break;

    case ($age <= 22);
    echo " You are Baby";
    break;

    default:
    echo " Not Match";
    break;

}



?>