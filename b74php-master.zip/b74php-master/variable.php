<?php  
    $abc123;
    $acb;
    $x;
    $abc_cda;
    $_abc;
    // $123abc
    $x = 123;
    echo $x; 
?>