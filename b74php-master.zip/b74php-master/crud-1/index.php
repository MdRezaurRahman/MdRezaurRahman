<?php  
    header("location: all.php");
?>