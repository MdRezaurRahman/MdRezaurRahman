<?php  
    $x = 10;
    echo $x;
    $x = 15;
    $x = 20;
    echo $x;
    echo "<br>";

    define("a", "Dhaka is the capital city of Bangladesh");
    echo a;

    // define("a", "our Bangladesh");
    define("b", "our Bangladesh");
?>