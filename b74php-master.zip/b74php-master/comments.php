<?php  
    // this is a single line comment
    # this is also a singleline comment
    /*
        this is a
        multiline
        comment
    */

    /* this is
     * also a
     * multiline
     * comment
     */
?>