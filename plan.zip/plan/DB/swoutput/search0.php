<?php
require_once dirname(__FILE__).('/../db_con.php');

class search_sewing_output extends DB_CON
{

    public function search($data)
    {
        $con = $this->connectToDB();

        $where = "";

        if(strlen($data['po_select']) > 0)
        {
            $where .= " and po = '".$data['po_select']."' ";
        }

        if(strlen($data['style_select']) > 0)
        {
            $where .= " and style = '".$data['style_select']."' ";
        }

        if(strlen($data['line_select']) > 0)
        {
            $where .= " and line = '".$data['line_select']."' ";
        }

        if(strlen($data['to_date']) > 0)
        {
            $from = date('Y-m-d', strtotime($_POST['from_date']));
            $to = date('Y-m-d', strtotime($_POST['to_date']));

            $where .= " and date between '".$from."' and '".$to."' ";
        }

        $sql = "SELECT
        style, po, color,COUNT(*) AS qty,scan_user,date
        FROM swing_output_scan
        WHERE deletion_status != 1
        $where
        GROUP BY style,po
        order by id desc";

        $query_result = mysqli_query($con, $sql);
        if ($query_result) {
            return $query_result;
        } else {
            die('Query problem' . mysqli_error($con));
        }
    }

    public function search_swoutput_scan_by_style_po($style,$po,$data)
    {
      $con = $this->connectToDB();
      $where = "";
        if(strlen($data['to_date']) > 0)
        {
            $from = date('Y-m-d', strtotime($_POST['from_date']));
            $to = date('Y-m-d', strtotime($_POST['to_date']));

            $where .= " and date between '".$from."' and '".$to."' ";
        }

      $sql = "SELECT *,
              SUM(quantity) as t_qty
              FROM swing_output_scan
              WHERE deletion_status != 1
              and style = '$style'
              and po = '$po'
              $where
              GROUP BY country,line
              order by id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }
    public function search_swoutput_scan_sizes_by_style_po($style,$po,$data)
    {
      $con = $this->connectToDB();
      $where = "";
        if(strlen($data['to_date']) > 0)
        {
            $from = date('Y-m-d', strtotime($_POST['from_date']));
            $to = date('Y-m-d', strtotime($_POST['to_date']));

            $where .= " and date between '".$from."' and '".$to."' ";
        }

      $sql = "SELECT size
              FROM swing_output_scan
              WHERE deletion_status != 1
              and style = '$style'
              and po = '$po'
              $where
              GROUP BY size
              order by id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }
    public function search_swoutput_scan_size_qty_by_style_po_size($style,$po,$size,$country,$line,$data)
    {
      $con = $this->connectToDB();
      $where = "";
        if(strlen($data['to_date']) > 0)
        {
            $from = date('Y-m-d', strtotime($_POST['from_date']));
            $to = date('Y-m-d', strtotime($_POST['to_date']));

            $where .= " and date between '".$from."' and '".$to."' ";
        }

      $sql = "SELECT SUM(quantity) as t_qty
              FROM swing_output_scan
              WHERE deletion_status != 1
              and style = '$style'
              and po = '$po'
              and size = '$size'
              and country = '$country'
              and line = '$line'
              $where
              -- GROUP BY size
              order by id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return mysqli_fetch_assoc($query_result);
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }

}

?>
