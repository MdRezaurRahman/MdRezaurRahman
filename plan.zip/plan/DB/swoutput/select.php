<?php
require_once dirname(__FILE__).('/../db_con.php');

class select_swoutput extends DB_CON
{
    public function select_all()
    {
        $con = $this->connectToDB();

        $sql = "SELECT distinct
                order_details.id,
                order_details.*,
                (select po_num from po where id = order_details.po)  as po_number,
                (select style_name from style where id = order_details.style)  as style_name,
                (select sum(quantity) from order_qtn_size where order_id = order_details.id)  as total_quantity,
                (select sum(quantity) from input_issue where order_id = order_details.id)  as total_issue_quantity,
                (select sum(quantity) from swing_output where order_id = order_details.id)  as total_output_quantity,
                (select user_name from user where id = swing_output.user_id)  as user_name
                FROM `order_details` left join `swing_output` on order_details.id = swing_output.order_id
                where swing_output.deletion_status != 1
                and order_details.id not in (select order_id from wash_send)
                order by order_details.id desc";

		$query_result = mysqli_query($con, $sql);
        if ($query_result) {
            return $query_result;
        } else {
            die('Query problem' . mysqli_error($con));
        }
    }


    public function select_all_input_issue_not_in_swing()
    {
        $con = $this->connectToDB();

        $sql = "SELECT
                order_details.*,
                (select po_num from po where id = order_details.po)  as po_number,
                (select style_name from style where id = order_details.style)  as style_name,
                (select sum(quantity) from order_qtn_size where order_id = order_details.id)  as total_quantity,
                0  as total_issue_quantity,
                (select user_name from user where id = order_details.cutting_user_id)  as user_name
                FROM `order_details`
                where deletion_status != 1
                and cutting_plan > 0
                and cutting_production = 0
                and order_details.id in (select order_id from input_issue)
                and order_details.id not in (select order_id from swing_output)
                order by order_details.id desc";
        $query_result = mysqli_query($con, $sql);
        if ($query_result) {
            return $query_result;
        } else {
            die('Query problem' . mysqli_error($con));
        }
    }


    public function select_with_id($id)
    {
        $con = $this->connectToDB();

        $sql = "SELECT distinct
                order_details.id,
                order_details.*,
                (select po_num from po where id = order_details.po)  as po_number,
                (select style_name from style where id = order_details.style)  as style_name,
                (select sum(quantity) from order_qtn_size where order_id = order_details.id)  as total_quantity,
                (select sum(issue_quantity) from order_qtn_size where order_id = order_details.id)  as total_issue_quantity,
                (select sum(quantity) from swing_output where order_id = order_details.id)  as total_output_quantity,
                (select user_name from user where id = swing_output.user_id)  as user_name
                FROM `order_details` left join `swing_output` on order_details.id = swing_output.order_id
                where swing_output.deletion_status != 1
                and id = '".$id."'";
        $query_result = mysqli_query($con, $sql);
        if ($query_result) {
            return $query_result;
        } else {
            die('Query problem' . mysqli_error($con));
        }
    }


    public function select_child_with_id($id)
    {
        $con = $this->connectToDB();

        $sql = "SELECT * FROM `swing_output` where order_id = '".$id."' and deletion_status != 1";
        $query_result = mysqli_query($con, $sql);
        if ($query_result) {
            return $query_result;
        } else {
            die('Query problem' . mysqli_error($con));
        }
    }

    public function select_child_with_order_and_country($order_id,$country_id)
    {
        $con = $this->connectToDB();

        $sql = "SELECT * FROM `swing_output` where order_id = '".$order_id."' and country_id = '".$country_id."' and deletion_status != 1";
        $query_result = mysqli_query($con, $sql);
        if ($query_result) {
            return $query_result;
        } else {
            die('Query problem' . mysqli_error($con));
        }
    }

    public function select_max_id_from_sweing_output()
    {
        $con = $this->connectToDB();

        $sql = "SELECT IFNULL(max(id),0) as max_id FROM `sewing_output` where deletion_status != 1";
        $query_result = mysqli_query($con, $sql);

        if ($result = mysqli_fetch_assoc($query_result)) {
            return $result['max_id'];
        } else {
            die('Query problem' . mysqli_error($con));
        }
    }

    public function select_scan_swoutput()
    {
      $con = $this->connectToDB();
      // $sql = "SELECT *
      //         FROM swing_output_scan
      //         WHERE id IN (
      //           SELECT MAX(id) FROM swing_output_scan
      //           GROUP BY style,po)
      //         and deletion_status != 1
      //         order by id desc";

              //       $sql="select style,
              // po, color,qty,scan_user,date
              // from (
              // SELECT style,po,color,COUNT(*) AS `qty`,scan_user,date
              //     from swing_output_scan GROUP BY style,po
              // )a";
              $sql = "SELECT
              style, po, color,COUNT(*) AS qty,scan_user,date
              FROM swing_output_scan
              WHERE deletion_status != 1
              GROUP BY style,po
              order by id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }

    public function select_line()
    {
      $con = $this->connectToDB();
              $sql = "SELECT
              distinct line
              FROM swing_output_scan
              WHERE deletion_status != 1
              order by id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }

    public function select_scan_swoutput_history()
    {
      $con = $this->connectToDB();


      $sql = "SELECT *
              FROM swing_output_scan
              WHERE id IN (
                SELECT MAX(id) FROM swing_output_scan
                GROUP BY complete_qr_code)
              and deletion_status != 1
              order by id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }

    public function select_scan_swoutput_today($date)
    {

      $con = $this->connectToDB();

      $sql = "SELECT line,style
              FROM swing_output_scan
              WHERE id IN (
                SELECT MAX(id) FROM swing_output_scan
                GROUP BY line,date)
              and deletion_status != 1
              and date = '$date'
              order by id desc";

//       $sql="select Line,style,
// case when Hours = '7:00-8:00' then cnt else 0 end as '1st HR(7-8)AM',
// case when Hours = '8:00-9:00' then cnt else 0 end as '2nd HR(8-9)AM',
// case when Hours = '9:00-10:00' then cnt else 0 end as '3rd HR(9-10)AM',
// case when Hours = '10:00-11:00' then cnt else 0 end as '4th HR(10-11)AM',
// case when Hours = '11:00-12:00' then cnt else 0 end as '5th HR(11-12)AM',
// case when Hours = '12:00-13:00' then cnt else 0 end as '6th HR(12-1)PM',
// case when Hours = '13:00-14:00' then cnt else 0 end as '7th HR(1-2)PM',
// case when Hours = '14:00-15:00' then cnt else 0 end as '8th HR(2-3)PM',
// case when Hours = '15:00-16:00' then cnt else 0 end as '9th HR(3-4)PM',
// case when Hours = '16:00-17:00' then cnt else 0 end as '10th HR(4-5)PM',
// case when Hours = '17:00-18:00' then cnt else 0 end as '11th HR(5-6)PM',
// case when Hours = '18:00-19:00' then cnt else 0 end as '12th HR(6-7)PM',
// case when Hours = '19:00-20:00' then cnt else 0 end as '13th HR(7-8)PM',
// case when Hours = '20:00-21:00' then cnt else 0 end as '14th HR(8-9)PM',
// case when Hours = '21:00-22:00' then cnt else 0 end as '15th HR(9-10)PM',
// Quantity, Date,id,Hours,cnt
//
//
//
// from (
// SELECT   line,style,quantity,date,id,CONCAT(HOUR(time), ':00-', HOUR(time)+1, ':00') AS Hours,COUNT(*) AS `cnt`
//     from swing_output_scan GROUP BY date,line
// )a WHERE date = '$date'";

//$sql="select * from swing_output_scan";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }


    public function select_scan_swoutput_today_by_line($line,$date)
    {

      $con = $this->connectToDB();

      $sql = "SELECT *
              FROM swing_output_scan
              WHERE line = '$line'
              and date = '$date'
              and deletion_status != 1
              order by id desc";

//       $sql="select Line,style,
// case when Hours = '7:00-8:00' then cnt else 0 end as '1st HR(7-8)AM',
// case when Hours = '8:00-9:00' then cnt else 0 end as '2nd HR(8-9)AM',
// case when Hours = '9:00-10:00' then cnt else 0 end as '3rd HR(9-10)AM',
// case when Hours = '10:00-11:00' then cnt else 0 end as '4th HR(10-11)AM',
// case when Hours = '11:00-12:00' then cnt else 0 end as '5th HR(11-12)AM',
// case when Hours = '12:00-13:00' then cnt else 0 end as '6th HR(12-1)PM',
// case when Hours = '13:00-14:00' then cnt else 0 end as '7th HR(1-2)PM',
// case when Hours = '14:00-15:00' then cnt else 0 end as '8th HR(2-3)PM',
// case when Hours = '15:00-16:00' then cnt else 0 end as '9th HR(3-4)PM',
// case when Hours = '16:00-17:00' then cnt else 0 end as '10th HR(4-5)PM',
// case when Hours = '17:00-18:00' then cnt else 0 end as '11th HR(5-6)PM',
// case when Hours = '18:00-19:00' then cnt else 0 end as '12th HR(6-7)PM',
// case when Hours = '19:00-20:00' then cnt else 0 end as '13th HR(7-8)PM',
// case when Hours = '20:00-21:00' then cnt else 0 end as '14th HR(8-9)PM',
// case when Hours = '21:00-22:00' then cnt else 0 end as '15th HR(9-10)PM',
// Quantity, Date,id,Hours,cnt
//
//
//
// from (
// SELECT   line,style,quantity,date,id,CONCAT(HOUR(time), ':00-', HOUR(time)+1, ':00') AS Hours,COUNT(*) AS `cnt`
//     from swing_output_scan GROUP BY date,line
// )a WHERE date = '$date'";

//$sql="select * from swing_output_scan";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }



    public function select_swoutput_scan_by_style_po($style,$po)
    {
      $con = $this->connectToDB();

      $sql = "SELECT *,
              SUM(quantity) as t_qty
              FROM swing_output_scan
              WHERE deletion_status != 1
              and style = '$style'
              and po = '$po'
              GROUP BY country,line
              order by line";
      //       $sql="select Line,style,
      // case when Hours = '7:00-8:00' then cnt else 0 end as '1st HR(7-8)AM',
      // case when Hours = '8:00-9:00' then cnt else 0 end as '2nd HR(8-9)AM',
      // case when Hours = '9:00-10:00' then cnt else 0 end as '3rd HR(9-10)AM',
      // case when Hours = '10:00-11:00' then cnt else 0 end as '4th HR(10-11)AM',
      // case when Hours = '11:00-12:00' then cnt else 0 end as '5th HR(11-12)AM',
      // case when Hours = '12:00-13:00' then cnt else 0 end as '6th HR(12-1)PM',
      // case when Hours = '13:00-14:00' then cnt else 0 end as '7th HR(1-2)PM',
      // case when Hours = '14:00-15:00' then cnt else 0 end as '8th HR(2-3)PM',
      // case when Hours = '15:00-16:00' then cnt else 0 end as '9th HR(3-4)PM',
      // case when Hours = '16:00-17:00' then cnt else 0 end as '10th HR(4-5)PM',
      // case when Hours = '17:00-18:00' then cnt else 0 end as '11th HR(5-6)PM',
      // case when Hours = '18:00-19:00' then cnt else 0 end as '12th HR(6-7)PM',
      // case when Hours = '19:00-20:00' then cnt else 0 end as '13th HR(7-8)PM',
      // case when Hours = '20:00-21:00' then cnt else 0 end as '14th HR(8-9)PM',
      // case when Hours = '21:00-22:00' then cnt else 0 end as '15th HR(9-10)PM',
      // Quantity, Date,id,Hours,cnt
      //
      //
      //
      // from (
      // SELECT   line,style,quantity,date,id,CONCAT(HOUR(time), ':00-', HOUR(time)+1, ':00') AS Hours,COUNT(*) AS `cnt`
      //     from swing_output_scan GROUP BY Hours,line
      // )a";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }

    public function select_swoutput_scan_sizes_by_style_po($style,$po)
    {
      $con = $this->connectToDB();

      $sql = "SELECT size
              FROM swing_output_scan
              WHERE deletion_status != 1
              and style = '$style'
              and po = '$po'
              GROUP BY size
              order by id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }

    public function select_swoutput_scan_size_qty_by_style_po_size($style,$po,$size,$country,$line)
    {
      $con = $this->connectToDB();

      $sql = "SELECT SUM(quantity) as t_qty
              FROM swing_output_scan
              WHERE deletion_status != 1
              and style = '$style'
              and po = '$po'
              and size = '$size'
              and country = '$country'
              and line = '$line'
              -- GROUP BY size
              order by id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return mysqli_fetch_assoc($query_result);
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }

    public function select_scan_swoutput_by_style_po($line,$style,$po,$country_id,$size)
    {
      $con = $this->connectToDB();

      $sql = "SELECT *
              FROM swing_output_scan
              WHERE id IN (
                SELECT MAX(id) FROM swing_output_scan
                GROUP BY complete_qr_code)
              and deletion_status != 1
              and line = '$line'
              and style = '$style'
              and po = '$po'
              and country = '$country_id'
              and size = '$size'
              order by id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }

    public function select_scan_swoutput_by_style_po2($line,$style,$po,$country_id,$size,$from_date,$to_date)
    {
      $con = $this->connectToDB();

      $sql = "SELECT *
              FROM swing_output_scan
              WHERE id IN (
                SELECT MAX(id) FROM swing_output_scan
                GROUP BY complete_qr_code)
              and deletion_status != 1
              and line = '$line'
              and style = '$style'
              and po = '$po'
              and country = '$country_id'
              and size = '$size'
              and date between '$from_date' and '$to_date'
              order by id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }

    public function select_scan_swoutput_history1()
    {
      $con = $this->connectToDB();

      $sql = "SELECT COUNT(*) as rowNumber
              FROM swing_output_scan
              WHERE id IN (
                SELECT MAX(id) FROM swing_output_scan
                GROUP BY complete_qr_code)
              and deletion_status != 1
              order by id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }

    public function select_scan_swoutput_history3($search)
    {
      $con = $this->connectToDB();


      $sql = "SELECT *
              FROM swing_output_scan
              WHERE 1=1
              and (id Like '".$search."%'
                OR complete_qr_code Like '".$search."%')
              and id IN (
                SELECT MAX(id) FROM swing_output_scan
                GROUP BY complete_qr_code)
              and deletion_status != 1
              order by id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }

    public function select_scan_swoutput_history2($start,$length)
    {
      $con = $this->connectToDB();

      if($length!=-1){
      $sql = "SELECT *
              FROM swing_output_scan
              WHERE id IN (
                SELECT MAX(id) FROM swing_output_scan
                GROUP BY complete_qr_code)
              and deletion_status != 1
              order by id desc
              LIMIT ".
              $start."  ,".$length." ";
      }
      else {
      $sql = "SELECT *
              FROM swing_output_scan
              WHERE id IN (
                SELECT MAX(id) FROM swing_output_scan
                GROUP BY complete_qr_code)
              and deletion_status != 1
              order by id desc";
      }

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }

    public function select_scan_swoutput_total()
    {
      $con = $this->connectToDB();

      date_default_timezone_set("Asia/Dhaka");
      $year = date("Y");
      $month = date("m");
      $monthYear = $month."-".$year;

      $sql = "SELECT *,
              COUNT(id) as total_scan
              FROM `swing_output_scan`
              where swing_output_scan.date like '%".$monthYear."'
              and deletion_status != 1
              order by swing_output_scan.id desc";

      $query_result = mysqli_query($con, $sql);
      if ($query_result) {
          return $query_result;
      } else {
          die('Query problem' . mysqli_error($con));
      }
    }

}

?>
