<?php
require_once dirname(__FILE__).('/../db_con.php');

class search_cproduction extends DB_CON
{

    public function search($data)
    {
        $con = $this->connectToDB();

        $where = "";

        if(strlen($data['po_select']) > 0)
        {
            $where .= " and po = ".$data['po_select']." ";
        }

        if(strlen($data['buyer_select']) > 0)
        {
            $where .= " and buyer = ".$data['buyer_select']." ";
        }

        if(strlen($data['color_select']) > 0)
        {
            $where .= " and color = ".$data['color_select']." ";
        }

        if(strlen($data['style_select']) > 0)
        {
            $where .= " and style = ".$data['style_select']." ";
        }

        if(strlen($data['to_date']) > 0)
        {
            $from = date('d-m-Y', strtotime($_POST['from_date']));
            $to = date('d-m-Y', strtotime($_POST['to_date']));

            $where .= " and creation_date between '".$from."' and '".$to."' ";
        }


        $sql = "SELECT
                cutting_production.*,
                (select name from buyer where id = cutting_production.buyer)  as buyer_name,
                (select po_num from po where id = cutting_production.po)  as po_number,
                (select cut_num from cut_no where id = cutting_production.cut_num)  as cut_number,
                (select sum(quantity) from cut_pro_bundle where production_id = cutting_production.id)  as cutting_production,
                (select name from color where id = cutting_production.color)  as color,
                (select style_name from style where id = cutting_production.style)  as style_name,
                (select name from shade where id = cutting_production.shade)  as shade,
                (select user_name from user where id = cutting_production.creator_id)  as user_name
                FROM `cutting_production`
                where deletion_status != 1
                $where and cutting_production =0 
                order by cutting_production.creation_date desc";

        $query_result = mysqli_query($con, $sql);
        if ($query_result) {
            return $query_result;
        } else {
            die('Query problem' . mysqli_error($con));
        }
    }

}

?>