<?php header('Location: insert.php'); ?>
