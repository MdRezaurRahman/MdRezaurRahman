<?php
require_once dirname(__FILE__).'/header.php';
require_once dirname(__FILE__).'/navBar.php';
require_once dirname(__FILE__).'/sideBar.php';
require_once dirname(__FILE__).'/footer.php';
?>
