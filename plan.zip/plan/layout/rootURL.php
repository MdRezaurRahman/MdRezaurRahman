<?php

   //$baseUrl = "http://sewing.denimsdts.com/";
   $baseUrl = "http://localhost/plan/";
   $baseName = "plan";
   $baseIcon = "logo.png";
?>
